package Controller;

import Model.User;
import Model.UserRepository;
import Model.UserRequestDTO;
import Model.UserResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("user")
public class UserController {
    @Autowired
    private UserRepository repository;
       @GetMapping
        public List<UserResponseDTO> getAll(){
            List<UserResponseDTO> UserList = repository.findAll().stream().map(UserResponseDTO::new).toList();
            return UserList;

        }
        @PostMapping
        public void saveUser(@RequestBody UserRequestDTO data){
           User userData = new User(data);
           repository.save(userData);

    }
}
