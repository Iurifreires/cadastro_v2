package Model;

import java.util.Date;

public record UserResponseDTO(Long id, String name, Boolean ativo, Date dataNasc, String login, Date dataCad, String senha) {

 public UserResponseDTO(User user){
        this(user.getId(), user.getName(), user.getAtivo(), user.getDataNasc(), user.getLogin(), user.getDataCad(), user.getSenha());

    }

}

