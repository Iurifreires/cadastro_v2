package Model;

import java.util.Date;

public record UserRequestDTO(String name, Boolean ativo, Date dataNasc, String login, Date dataCad, String senha) {
}
