package Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.NoArgsConstructor;
import org.springframework.boot.autoconfigure.AutoConfiguration;

import java.util.Date;
@Entity (name = "user")
@Table (name = "usuarios")
@Getter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode (of = "id")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String login;
    private String name;
    private Date dataNasc;
    private Boolean ativo;
    private String senha;
    private Date dataCad = new Date();


    public User(UserRequestDTO data){
      this.login = data.login();
      this.name = data.name();
      this.dataNasc = data.dataNasc();
      this.dataCad = data.dataCad();
      this.ativo = data.ativo();
      this.senha = data.senha();
    }
}
