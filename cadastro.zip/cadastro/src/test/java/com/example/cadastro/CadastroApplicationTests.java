package com.example.cadastro;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CadastroApplicationTests {

	@Test
	void contextLoads() {
	}

}
